//
//  MainViewController.swift
//  childrenTimer
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    



}
