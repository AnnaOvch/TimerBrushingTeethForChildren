//
//  NightViewController.swift
//  childrenTimer
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit
import AVFoundation
class NightViewController: UIViewController {
    var player = AVAudioPlayer()
    
    var childrenTimer:Timer!
    var totalTime:Double = 150
    var isStopped = false
    var savedTotal:Double = 0
    var valueForSlider:Float = 0
    
    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var sLabel: UILabel!
    
    @IBOutlet weak var slider: UISlider!
        @IBAction func setSliderTime(_ sender: UISlider) {
        totalTime = Double(sender.value)
        valueForSlider = sender.value
        totalTime = Double(Int(totalTime)*60+Int((totalTime-Double(Int(totalTime)))*60.0))
        savedTotal = totalTime
        setValues()
        //if(B.isSelected == true){
            
       // }
            //stop.isSelected
            if(isStopped == true){
                
                changeContinueToStop.isSelected = false
            }
            
    }
    @IBOutlet weak var changeContinueToStop: UIButton!
    @IBAction func start(_ sender: UIButton) {
        setValues()
        startTimer()
    }
    
    @IBAction func stop(_ sender: UIButton) {
        
        
        if (isStopped == false){
            sender.isSelected = true
            isStopped = true
            endTimer()
            
            
        }else{
            isStopped = false
            sender.isSelected = false
            startTimer()
        }
    }
    
   
    func startTimer(){
        setValues()
        
        childrenTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
    }
    @objc func updateTime(){
        //setValues()
        if(totalTime>0){
            totalTime = totalTime - 1
            setValues()
        }else{
            endTimer()
            player.play()
            totalTime = savedTotal
            setValues()
            slider.value = valueForSlider
        }
        
    }
    
    func endTimer(){
        childrenTimer.invalidate()
        
    }
    func setValues1(){
        mLabel.text = String( Int(totalTime))
        sLabel.text = String(format:"%.02d",Int((totalTime-Double(Int(totalTime)))*60 ))
        
    }
    func setValues(){
        mLabel.text = String(Int(totalTime/60))
        sLabel.text = String(format:"%.02d",Int(totalTime.truncatingRemainder(dividingBy: 60)))
        
    }
    override func viewDidLoad() {
        do{
            let audioPath = Bundle.main.path(forResource:"bell" ,ofType:"mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
            
        }catch{
            print("Error with audio!")
        }
        super.viewDidLoad()
        slider.value=2.5
        mLabel.text = "2"
        sLabel.text = "30"
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
}


